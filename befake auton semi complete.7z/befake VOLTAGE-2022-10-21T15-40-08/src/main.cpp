/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// Colorroller          motor         16              
// Motor11              motor         11              
// Motor1               motor         1               
// Motor10              motor         10              
// Motor20              motor         20              
// Motor6               motor         6               
// Motor5               motor         5               
// Intake               motor         8               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
double wheelTravel = 3.25 * M_PI;


//LOOKHERE
double gearRatio = .5;

double volts = 12;
// A global instance of competition
competition Competition;
  motor_group driveL(Motor11,Motor1);
  motor_group driveR(Motor10,Motor20);
    motor_group shooter(Motor6,Motor5);
  inertial DrivetrainIntertial = inertial(PORT9);  
  smartdrive Drivetrain =  smartdrive(driveL, driveR, DrivetrainIntertial, wheelTravel , 3.25, gearRatio );




void Ldrive(){
driveL.setVelocity(Controller1.Axis3.position(),percent);

driveL.spin(forward);

}
void Rdrive(){

driveR.setVelocity(Controller1.Axis2.position(),percent);

driveR.spin(forward);




}



  void whenControllerR1Pressed() {
  Intake.setVelocity(100,percent);
  shooter.spin(reverse, 12.0, voltageUnits::volt);
  while(80 < shooter.velocity(percent)){
    wait(10, msec);

  }

      Intake.spin(forward);

  waitUntil(!Controller1.ButtonR1.pressing());
  
  shooter.stop();

  Intake.stop();

  
}

  void whenControllerR2Pressed() {


  shooter.spin(reverse, 12.0, voltageUnits::volt);
  waitUntil(!Controller1.ButtonR2.pressing());

  shooter.stop();



  
}
  void whenControllerL1Pressed() {
  Colorroller.setVelocity(100, percent);
  Colorroller.spin(reverse);
  waitUntil(!Controller1.ButtonL1.pressing());
  Colorroller.stop();
  Colorroller.stop();


  
}
    void whenControllerL2Pressed() {
  Colorroller.setVelocity(100, percent);
  Colorroller.spin(reverse);
  waitUntil(!Controller1.ButtonL2.pressing());
  Colorroller.stop();
  Colorroller.stop();
    }

    void whenButtonYPressed(){
      shooter.setVelocity(10,percent);
      Intake.setVelocity(40,percent);
      Intake.spin(reverse);
      shooter.spin(forward);
      waitUntil(!Controller1.ButtonY.pressing());
      Intake.stop();
      shooter.stop();


    }
        void whenButtonsPressedChangeVolt(){
          if (Controller1.ButtonX.pressing()) {
            volts = 12;

          }
                    if (Controller1.ButtonA.pressing()) {
            volts = 10;

          }
                    if (Controller1.ButtonB.pressing()) {
            volts = 8;

          }

    }

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  shooter.setVelocity(100,percent);
  Intake.setVelocity(100,percent);
  




  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {

  /*
  Drivetrain.driveFor(forward,5,mm);
  
Colorroller.spinFor(forward,4,turns);
  Drivetrain.driveFor(reverse,6,mm);
    Drivetrain.driveFor(reverse,6,mm);
    */
  shooter.setVelocity(100,percent);
    shooter.spinFor(reverse,3,seconds);
    shooter.spin(reverse,12.0, voltageUnits::volt);
    Intake.spin(forward,12.0, voltageUnits::volt);
    wait(3,seconds);
    Intake.stop();
        Intake.spin(forward,12.0, voltageUnits::volt);
        wait(1,seconds);
        Intake.stop();
        
        Drivetrain.setDriveVelocity(80,percent);
        Drivetrain.setTurnVelocity(80,percent);
        Drivetrain.setHeading(270,degrees);
        Drivetrain.turnToHeading(0,degrees);
        Drivetrain.driveFor(4,inches);
        Drivetrain.setDriveVelocity(40,percent);

        //intake fires
      Intake.spin(forward);
      shooter.setVelocity(30,percent);
      shooter.spin(forward);
        Drivetrain.driveFor(4, inches);
        Intake.stop();
        shooter.stop();
        Drivetrain.turnToHeading(253,degrees);
        shooter.spin(reverse,12.0, voltageUnits::volt);
        wait(2,seconds);
        Intake.spin(forward);
        wait(1,seconds);
        Intake.stop();
        wait(1,seconds);
        Intake.spin(forward);
        wait(1,seconds);
        Intake.stop();
        Drivetrain.turnToHeading(137,degrees);

        Drivetrain.setDriveVelocity(85,percent);
        Drivetrain.driveFor(15,inches);
        Drivetrain.turnToHeading(180,degrees);
        Drivetrain.driveFor(6,inches);
        Colorroller.spinFor(reverse,1.5,turns);



    shooter.stop();
    Intake.stop();







}


/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {

    whenControllerR2Pressed();
    whenControllerR1Pressed();
    whenControllerL2Pressed();
    whenControllerL1Pressed();
    whenButtonYPressed();
    Rdrive();
    Ldrive();
      Brain.Screen.print(shooter.velocity(percent));
   
  

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
