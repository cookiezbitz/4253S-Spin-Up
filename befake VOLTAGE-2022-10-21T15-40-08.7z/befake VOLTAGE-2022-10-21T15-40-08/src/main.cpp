/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// Colorroller          motor         16              
// Motor11              motor         11              
// Motor1               motor         1               
// Motor10              motor         10              
// Motor20              motor         20              
// Motor6               motor         6               
// Intake               motor         8               
// piston               digital_out   A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
double wheelTravel = 3.25 * M_PI;


//LOOKHERE
double gearRatio = 2;

double volts = 12;
double voltstemp = 0;
// A global instance of competition
competition Competition;
  motor_group driveL(Motor11,Motor1);
  motor_group driveR(Motor10,Motor20);
    motor_group shooter(Motor6);
  inertial DrivetrainIntertial = (PORT17);
  smartdrive Drivetrain =  smartdrive(driveL, driveR, DrivetrainIntertial, wheelTravel , 3.25, gearRatio );

bool flipdirection = false;

void Ldrive(){
driveL.setVelocity(Controller1.Axis3.position(),percent);

if(flipdirection == false){
  
driveL.spin(forward);
}else{
  driveL.spin(reverse);

}



}
void Rdrive(){

driveR.setVelocity(Controller1.Axis2.position(),percent);

if(flipdirection == false){
  
driveR.spin(forward);
}else{
  driveR.spin(reverse);
  
}






}




  void whenControllerR1Pressed() {
  Intake.setVelocity(100,percent);
     voltstemp = volts;
  shooter.spin(reverse,voltstemp, voltageUnits::volt);

      Intake.spin(forward);

bool penis;
penis = true;
  waitUntil(!Controller1.ButtonR1.pressing());

  penis = false;
voltstemp = 0;

Ldrive();
Rdrive();
  
  shooter.stop();

  Intake.stop();

  
}




  void whenControllerR2Pressed() {

    voltstemp = volts;

  shooter.spin(reverse,voltstemp, voltageUnits::volt);
  waitUntil(!Controller1.ButtonR2.pressing());

  voltstemp = 0;
  shooter.stop();



  
}
  void whenControllerL1Pressed() {
  Colorroller.setVelocity(100, percent);
  Colorroller.spin(reverse);
  waitUntil(!Controller1.ButtonL1.pressing());
  Colorroller.stop();
  Colorroller.stop();


  
}
    void whenControllerL2Pressed() {
  Colorroller.setVelocity(100, percent);
  Colorroller.spin(reverse);
  waitUntil(!Controller1.ButtonL2.pressing());
  Colorroller.stop();
  Colorroller.stop();
    }

    void whenButtonYPressed(){
      shooter.setVelocity(10,percent);
      Intake.setVelocity(40,percent);
      Intake.spin(reverse);
      shooter.spin(forward);
      waitUntil(!Controller1.ButtonY.pressing());
      Intake.stop();
      shooter.stop();


    }
              void whenButtonDownPressed(){
            if(Controller1.ButtonDown.pressing()){
              piston.set(true);
            }

            if(Controller1.ButtonRight.pressing()){
              flipdirection = !flipdirection;
              }
          


          }
        void whenButtonsPressedChangeVolt(){
          if (Controller1.ButtonX.pressing()) {
            volts = 11;

          }
                    if (Controller1.ButtonA.pressing()) {
            volts = 10;

          }
                    if (Controller1.ButtonB.pressing()) {
            volts = 9;

          }

                              if (Controller1.ButtonUp.pressing()) {
            volts = 0;

          }



    }

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
shooter.setStopping(coast);
  shooter.setVelocity(100,percent);
  Intake.setVelocity(100,percent);
  volts = 12;


  




  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {




      float tile;
  tile = 2; //times the value of the actual distence for 1000 mm




//first section gets the roller

Colorroller.setStopping(hold);
Drivetrain.setStopping(hold);

Drivetrain.setDriveVelocity(25,percent);
Drivetrain.setTurnVelocity(15,percent);
Intake.setVelocity(70,percent);

//robot will start with head towards the color roller
Drivetrain.setHeading(270,degrees);
Colorroller.setVelocity(100,percent);


Drivetrain.driveFor(forward,.8*tile,inches);
Drivetrain.turnToHeading(0,degrees);
Drivetrain.setStopping(coast);
Drivetrain.setDriveVelocity(15,percent);
Drivetrain.driveFor(forward, tile*.17,inches);
Drivetrain.setStopping(hold);
wait(.5,seconds);


Colorroller.setVelocity(50,percent);
Colorroller.spinFor(reverse,.25,turns);
wait(.5,seconds);

//end of first section, second section starts shooting

Drivetrain.driveFor(reverse,tile*.20,inches);


}


/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {

    whenControllerR2Pressed();
   whenControllerR1Pressed();
    
    whenControllerL2Pressed();
    whenControllerL1Pressed();
    
    whenButtonYPressed();
    whenButtonDownPressed();
   whenButtonsPressedChangeVolt();
    Rdrive();
    Ldrive();

    Brain.Screen.print("Shooter stats");
    Brain.Screen.newLine();
      Brain.Screen.print("The shooter is running at ", shooter.velocity(rpm), "and " , shooter.power());
      Brain.Screen.newLine();
            Brain.Screen.print("The shooter is", shooter.temperature());
            Brain.Screen.newLine();
            Brain.Screen.print("The Drivetrain is ", driveL.temperature() , "and " , driveR.temperature() )    ;  
      
      
      
      
   
  

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
