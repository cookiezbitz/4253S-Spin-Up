/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// Colorroller          motor         16              
// Motor11              motor         11              
// Motor1               motor         1               
// Motor10              motor         10              
// Motor20              motor         20              
// Motor6               motor         6               
// Intake               motor         8               
// piston               digital_out   A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
double wheelTravel = 3.25 * M_PI;


//LOOKHERE
double gearRatio = 2;

double volts = 12;
double voltstemp = 0;
// A global instance of competition
competition Competition;
  motor_group driveL(Motor11,Motor1);
  motor_group driveR(Motor10,Motor20);
    motor_group shooter(Motor6);
  inertial DrivetrainIntertial = (PORT17);
  smartdrive Drivetrain =  smartdrive(driveL, driveR, DrivetrainIntertial, wheelTravel , 3.25, gearRatio );

bool flipdirection = false;

void Ldrive(){
driveL.setVelocity(Controller1.Axis3.position(),percent);

if(flipdirection == false){
  
driveL.spin(forward);
}else{
  driveL.spin(reverse);

}



}
void Rdrive(){

driveR.setVelocity(Controller1.Axis2.position(),percent);

if(flipdirection == false){
  
driveR.spin(forward);
}else{
  driveR.spin(reverse);
  
}






}




  void whenControllerR1Pressed() {
  Intake.setVelocity(100,percent);
     voltstemp = volts;
  shooter.spin(reverse,voltstemp, voltageUnits::volt);

      Intake.spin(forward);

bool penis;
penis = true;
  waitUntil(!Controller1.ButtonR1.pressing());

  penis = false;
voltstemp = 0;

Ldrive();
Rdrive();
  
  shooter.stop();

  Intake.stop();

  
}




  void whenControllerR2Pressed() {

    voltstemp = volts;

  shooter.spin(reverse,voltstemp, voltageUnits::volt);
  waitUntil(!Controller1.ButtonR2.pressing());

  voltstemp = 0;
  shooter.stop();



  
}
  void whenControllerL1Pressed() {
  Colorroller.setVelocity(100, percent);
  Colorroller.spin(reverse);
  waitUntil(!Controller1.ButtonL1.pressing());
  Colorroller.stop();
  Colorroller.stop();


  
}
    void whenControllerL2Pressed() {
  Colorroller.setVelocity(100, percent);
  Colorroller.spin(reverse);
  waitUntil(!Controller1.ButtonL2.pressing());
  Colorroller.stop();
  Colorroller.stop();
    }

    void whenButtonYPressed(){
      shooter.setVelocity(10,percent);
      Intake.setVelocity(40,percent);
      Intake.spin(reverse);
      shooter.spin(forward);
      waitUntil(!Controller1.ButtonY.pressing());
      Intake.stop();
      shooter.stop();


    }
              void whenButtonDownPressed(){
            if(Controller1.ButtonDown.pressing()){
              piston.set(true);
            }

            if(Controller1.ButtonRight.pressing()){
              flipdirection = !flipdirection;
              }
          


          }
        void whenButtonsPressedChangeVolt(){
          if (Controller1.ButtonX.pressing()) {
            volts = 11;

          }
                    if (Controller1.ButtonA.pressing()) {
            volts = 10;

          }
                    if (Controller1.ButtonB.pressing()) {
            volts = 9;

          }

                              if (Controller1.ButtonUp.pressing()) {
            volts = 0;

          }



    }

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
shooter.setStopping(coast);
  shooter.setVelocity(100,percent);
  Intake.setVelocity(100,percent);
  volts = 12;


  




  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {



  /*
  Drivetrain.driveFor(forward,5,mm);
  
Colorroller.spinFor(forward,4,turns);
  Drivetrain.driveFor(reverse,6,mm);
    Drivetrain.driveFor(reverse,6,mm);
    */


      float tile;
  tile = 2; //times the value of the actual distence for 1000 mm




//first section gets the roller

Colorroller.setStopping(hold);
Drivetrain.setStopping(hold);

Drivetrain.setDriveVelocity(25,percent);
Drivetrain.setTurnVelocity(15,percent);
Intake.setVelocity(70,percent);

//robot will start with head towards the color roller
Drivetrain.setHeading(270,degrees);
Colorroller.setVelocity(100,percent);


Drivetrain.driveFor(forward,.8*tile,inches);
Drivetrain.turnToHeading(0,degrees);
Drivetrain.setStopping(coast);
Drivetrain.setDriveVelocity(15,percent);
Drivetrain.driveFor(forward, tile*.17,inches);
Drivetrain.setStopping(hold);
wait(.5,seconds);


Colorroller.setVelocity(50,percent);
Colorroller.spinFor(reverse,.25,turns);
wait(.5,seconds);

//end of first section, second section starts shooting

Drivetrain.driveFor(reverse,tile*.20,inches);

/*

//20 inches
//17 inches + a little more

shooter.setVelocity(30, percent); 
Intake.spin(forward);
shooter.spin(forward);
*/
/*
Drivetrain.turnToHeading(315,degrees);
Drivetrain.setDriveVelocity(75,percent);

Drivetrain.driveFor(reverse,tile*2.83, inches);
Drivetrain.turnToHeading(41.34,degrees);
Drivetrain.driveFor(reverse,tile*.30,inches);

shooter.spin(reverse,10.16, voltageUnits::volt);
Intake.setVelocity(100,percent);

wait(3,seconds);
Intake.spin(forward);
wait(.35,seconds);
Intake.stop();
wait(2.7,seconds);
Intake.setVelocity(100,percent);
Intake.spin(forward);
wait(2,seconds);
Intake.stop();
shooter.stop();
*/


/*
Intake.stop();
shooter.stop();
shooter.spin(reverse,12.0, voltageUnits::volt);
Drivetrain.turnToHeading(304,degrees);
Intake.spin(forward);
wait(1,seconds);
Intake.stop();
wait(1,seconds);
Intake.spin(forward);
wait(1,seconds);
Intake.stop();
*/












/*
Drivetrain.setHeading(180,degrees);
//sets the heading to that of the shooter

Drivetrain.setDriveVelocity(85,percent);
Drivetrain.setTurnVelocity(45,percent);
Intake.setVelocity(70,percent);

Drivetrain.driveFor(reverse,travel*.356,mm);
shooter.spin(reverse,12.0, voltageUnits::volt);

//here
Drivetrain.turnToHeading(35, degrees);
Intake.spin(forward);
wait(.8,seconds);
Intake.stop();
wait(1,seconds);
Intake.spin(forward);
wait(.8, seconds);
Intake.stop();
shooter.stop();

//this turn to heading is 180 + the first turn to heading degree
Drivetrain.turnToHeading(215,degrees);
Intake.spin(forward);
shooter.spin(forward,4.0, voltageUnits::volt);
Drivetrain.setDriveVelocity(40,percent);
Drivetrain.driveFor(forward,travel*.25,mm);
Intake.stop();
wait(.2,seconds);
shooter.stop();

shooter.spin(reverse,12.0, voltageUnits::volt);
Drivetrain.turnToHeading(35,degrees);
*/






    /*
  shooter.setVelocity(100,percent);
    shooter.spinFor(reverse,3,seconds);
    shooter.spin(reverse,12.0, voltageUnits::volt);
    Intake.spin(forward,12.0, voltageUnits::volt);
    wait(3,seconds);
    Intake.stop();
        Intake.spin(forward,12.0, voltageUnits::volt);
        wait(1,seconds);
        Intake.stop();
        
        Drivetrain.setDriveVelocity(80,percent);
        Drivetrain.setTurnVelocity(80,percent);
        Drivetrain.setHeading(270,degrees);
        Drivetrain.turnToHeading(0,degrees);
        Drivetrain.driveFor(4,inches);
        Drivetrain.setDriveVelocity(40,percent);

        //intake fires
      Intake.spin(forward);
      shooter.setVelocity(30,percent);
      shooter.spin(forward);
        Drivetrain.driveFor(4, inches);
        Intake.stop();
        shooter.stop();
        Drivetrain.turnToHeading(253,degrees);
        shooter.spin(reverse,12.0, voltageUnits::volt);
        wait(2,seconds);
        Intake.spin(forward);
        wait(1,seconds);
        Intake.stop();
        wait(1,seconds);
        Intake.spin(forward);
        wait(1,seconds);
        Intake.stop();
        Drivetrain.turnToHeading(137,degrees);

        Drivetrain.setDriveVelocity(85,percent);
        Drivetrain.driveFor(15,inches);
        Drivetrain.turnToHeading(180,degrees);
        Drivetrain.driveFor(6,inches);
        Colorroller.spinFor(reverse,1.5,turns);



    shooter.stop();
    Intake.stop();
    */







}


/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {

    whenControllerR2Pressed();
   whenControllerR1Pressed();
    
    whenControllerL2Pressed();
    whenControllerL1Pressed();
    
    whenButtonYPressed();
    whenButtonDownPressed();
   whenButtonsPressedChangeVolt();
    Rdrive();
    Ldrive();
      Brain.Screen.print(shooter.velocity(percent));
      
      
   
  

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
